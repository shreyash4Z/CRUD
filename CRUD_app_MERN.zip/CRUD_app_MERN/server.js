const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 5000;

// MongoDB Connection
mongoose.connect('mongodb://localhost:27017/itemsDB', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(() => {
  console.log('Connected to MongoDB');
}).catch((error) => {
  console.error('Error connecting to MongoDB:', error);
});

// Define a Mongoose schema and model for 'Item'
const itemSchema = new mongoose.Schema({
  name: String,
});

const Item = mongoose.model('Item', itemSchema);

// Middleware to serve static files from 'client' folder
app.use(express.static(path.join(__dirname, 'client')));
app.use(express.json());  // To parse JSON bodies for POST and PUT requests

// GET route to fetch items from MongoDB
app.get('/items', async (req, res) => {
  try {
    const items = await Item.find();  // Fetch items from MongoDB
    res.json(items);  // Send the items as JSON response
  } catch (error) {
    res.status(500).send('Error fetching items');
  }
});

// POST route to add a new item to MongoDB
app.post('/items', async (req, res) => {
  const newItem = new Item({
    name: req.body.name,
  });
  try {
    const savedItem = await newItem.save();  // Save the item to MongoDB
    res.status(201).json(savedItem);  // Respond with the saved item
  } catch (error) {
    res.status(500).send('Error adding item');
  }
});

// PUT route to update an item in MongoDB
app.put('/items/:id', async (req, res) => {
  const itemId = req.params.id;
  const updatedName = req.body.name;
  try {
    const updatedItem = await Item.findByIdAndUpdate(
      itemId,
      { name: updatedName },
      { new: true }  // Return the updated item
    );
    if (updatedItem) {
      res.json(updatedItem);  // Send the updated item
    } else {
      res.status(404).send('Item not found');
    }
  } catch (error) {
    res.status(500).send('Error updating item');
  }
});

// DELETE route to remove an item from MongoDB
app.delete('/items/:id', async (req, res) => {
  const itemId = req.params.id;
  try {
    await Item.findByIdAndDelete(itemId);  // Delete the item from MongoDB
    res.status(204).send();  // Send no content status code
  } catch (error) {
    res.status(500).send('Error deleting item');
  }
});

// Serve the index.html when accessing the root of the server
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'client', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
