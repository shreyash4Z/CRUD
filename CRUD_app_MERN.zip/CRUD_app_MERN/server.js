const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 5000;

mongoose.connect('mongodb://localhost:27017/itemsDB', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(() => {
  console.log('Connected to MongoDB');
}).catch((error) => {
  console.error('Error connecting to MongoDB:', error);
});

const itemSchema = new mongoose.Schema({
  name: String,
});

const Item = mongoose.model('Item', itemSchema);

app.use(express.static(path.join(__dirname, 'client')));
app.use(express.json());  

app.get('/items', async (req, res) => {
  try {
    const items = await Item.find();  
    res.json(items);  
  } catch (error) {
    res.status(500).send('Error fetching items');
  }
});

app.post('/items', async (req, res) => {
  const newItem = new Item({
    name: req.body.name,
  });
  try {
    const savedItem = await newItem.save();  
    res.status(201).json(savedItem);  
  } catch (error) {
    res.status(500).send('Error adding item');
  }
});

app.put('/items/:id', async (req, res) => {
  const itemId = req.params.id;
  const updatedName = req.body.name;
  try {
    const updatedItem = await Item.findByIdAndUpdate(
      itemId,
      { name: updatedName },
      { new: true }  
    );
    if (updatedItem) {
      res.json(updatedItem);  
    } else {
      res.status(404).send('Item not found');
    }
  } catch (error) {
    res.status(500).send('Error updating item');
  }
});

app.delete('/items/:id', async (req, res) => {
  const itemId = req.params.id;
  try {
    await Item.findByIdAndDelete(itemId);  
    res.status(204).send();  
  } catch (error) {
    res.status(500).send('Error deleting item');
  }
});

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'client', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
